//
//  CMNewFeaturesController.h
//  CMKit
//
//  Created by HC on 16/11/7.
//  Copyright © 2016年 UTOUU. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CMNewFeaturesController : UIViewController

/**
 新特性图片数组
 */
@property (nonatomic, strong) NSArray *featuresArray;

@end
