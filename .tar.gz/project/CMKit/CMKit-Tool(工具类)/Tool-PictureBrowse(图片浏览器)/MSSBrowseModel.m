//
//  MSSBrowseModel.m
//  MSSBrowse
//
//  Created by 于威 on 15/12/5.
//  Copyright © 2015年 于威. All rights reserved.
//

#import "MSSBrowseModel.h"

@implementation MSSBrowseModel

@end
