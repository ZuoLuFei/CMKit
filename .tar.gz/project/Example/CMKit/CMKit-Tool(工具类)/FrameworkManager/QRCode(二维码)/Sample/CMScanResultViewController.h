//
//  CMScanResultViewController.h
//  CMKit
//
//  Created by HC on 16/12/2.
//  Copyright © 2016年 UTOUU. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CMScanResultViewController : UIViewController

@property (nonatomic, strong) UIImage *imgScan;
@property (nonatomic, copy) NSString *strScan;

@property (nonatomic,copy)NSString *strCodeType;


@end
