//
//  CMLaunchAdWebSampleController.h
//  CMKit
//
//  Created by HC on 16/12/26.
//  Copyright © 2016年 UTOUU. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CMLaunchAdWebSampleController : UIViewController

@property (nonatomic, copy) NSString *URLString;

@end
