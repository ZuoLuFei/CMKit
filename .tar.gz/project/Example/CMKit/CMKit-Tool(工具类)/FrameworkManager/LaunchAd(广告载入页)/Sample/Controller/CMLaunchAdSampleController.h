//
//  CMLaunchAdSampleController.h
//  CMKit
//
//  Created by HC on 16/12/26.
//  Copyright © 2016年 UTOUU. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CMLaunchAdSampleController : UIViewController

@end
